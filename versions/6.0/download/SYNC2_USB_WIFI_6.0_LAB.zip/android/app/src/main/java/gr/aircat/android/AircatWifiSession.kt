package gr.aircat.android

import java.io.BufferedWriter
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.time.Instant
import java.util.ArrayDeque
import java.util.Locale
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** The render queue is bounded independently from recording and recent history. */
class WifiFrameBuffer(private val historyLimit: Int=4096, private val displayLimit: Int=1024) {
    private val history=ArrayDeque<RadarPacket>()
    private val display=ArrayDeque<RadarPacket>()
    @Volatile var displayDropped=0L;private set
    @Synchronized fun add(packet: RadarPacket) {
        history.addLast(packet);while(history.size>historyLimit)history.removeFirst()
        if(display.size>=displayLimit){display.removeFirst();displayDropped++}
        display.addLast(packet)
    }
    @Synchronized fun drain(limit: Int=256): List<RadarPacket> {
        val out=ArrayList<RadarPacket>()
        repeat(minOf(limit,display.size)){out.add(display.removeFirst())}
        return out
    }
    @Synchronized fun recent(): List<RadarPacket> = history.toList()
}

data class WifiRecordRow(val packet: RadarPacket,val wifi: WifiCounters)

/** Same accepted-frame CSV contract as Python. Never writes from the UI thread. */
class WifiCsvRecorder(
    private val onFinished: (Long,String?)->Unit = {_,_->},
    private val open: ()->OutputStream
) {
    private val queue=LinkedBlockingQueue<WifiRecordRow>(2048)
    private val lock=Any()
    @Volatile private var accepting=true
    @Volatile var finished=false;private set
    @Volatile var rows=0L;private set
    @Volatile var error: String?=null;private set
    init { thread(name="AIRCAT WiFi CSV",isDaemon=true){writeLoop()} }
    fun offer(row: WifiRecordRow) = synchronized(lock) {
        if(accepting && !queue.offer(row)) {
            error="Η ουρά εγγραφής γέμισε. Η εγγραφή σταμάτησε· έλεγξε τον χώρο αποθήκευσης."
            accepting=false
        }
    }
    fun stop()=synchronized(lock){accepting=false}
    fun isAccepting()=accepting
    private fun writeLoop() {
        try {
            BufferedWriter(OutputStreamWriter(open(),Charsets.UTF_8),64*1024).use { writer ->
                writer.write("\uFEFF" + LiveCsv.HEADER + "\n")
                var flushAt=System.nanoTime()
                while(accepting || queue.isNotEmpty()) {
                    val row=queue.poll(100,TimeUnit.MILLISECONDS)
                    if(row!=null) {
                        writer.write(LiveCsv.row(row.packet) + "\n")
                        rows++
                    }
                    if(System.nanoTime()-flushAt>=1_000_000_000L){writer.flush();flushAt=System.nanoTime()}
                }
                writer.flush()
            }
        } catch(ex: Exception){error="Αποτυχία εγγραφής CSV: ${ex.message}"}
        finally {
            accepting=false
            try { onFinished(rows,error) } finally { finished=true }
        }
    }
}

internal fun formatRecordDuration(seconds: Long): String {
    val total=seconds.coerceAtLeast(0)
    return when {
        total<60 -> "%02ds".format(Locale.US,total)
        total<3600 -> "%d:%02dmin".format(Locale.US,total/60,total%60)
        else -> "%dh:%02dm".format(Locale.US,total/3600,(total/60)%60)
    }
}

data class WifiSessionSnapshot(val transport: WifiCounters=WifiCounters(),
    val bsc: LiveBscCounters=LiveBscCounters(),val message: String="Αναμονή HELLO/ACK...",
    val running: Boolean=true,val lastDataAgoMs: Long?=null,val timing: LiveTimingSnapshot=LiveTimingSnapshot(),
    val lastAckAgoMs: Long?=null,val helloSent: Long=0,val ackReceived: Long=0)

/** Socket binding is injected so the transport is also JVM-testable. */
class AircatWifiSession(
    private val bindSocket: (DatagramSocket)->Unit,
    private val host: String="192.168.4.1",private val dataPort: Int=5005,private val helloPort: Int=5006,
    private val pin: String="1234",private val handshakeTimeoutMs: Long=22000, private val ackTimeoutMs: Long=9000
) : AutoCloseable {
    val frames=WifiFrameBuffer()
    @Volatile var snapshot=WifiSessionSnapshot();private set
    @Volatile var recorder: WifiCsvRecorder?=null;private set
    @Volatile private var stopped=false
    @Volatile private var dataSocket: DatagramSocket?=null
    @Volatile private var helloSocket: DatagramSocket?=null
    @Volatile private var started=false
    @Synchronized fun start() {
        check(!started){"Session already started"};started=true
        require(Regex("[0-9]{4}").matches(pin)){"Το PIN πρέπει να έχει 4 ψηφία"}
        thread(name="AIRCAT WiFi receiver",isDaemon=true){receiveLoop()}
    }
    @Synchronized fun record(onFinished: (Long,String?)->Unit = {_,_->},open: ()->OutputStream): WifiCsvRecorder {
        check(!stopped && started){"Δεν υπάρχει ενεργή λήψη"}
        check(recorder?.finished!=false){"Η προηγούμενη εγγραφή δεν έχει ολοκληρωθεί"}
        return WifiCsvRecorder(onFinished,open).also{recorder=it}
    }
    fun stopRecording(){recorder?.stop()}
    private fun monotonicMs()=System.nanoTime()/1_000_000L
    @Synchronized private fun openSockets(): Pair<DatagramSocket,DatagramSocket>? {
        if(stopped)return null
        val data=DatagramSocket(null)
        dataSocket=data
        data.receiveBufferSize=262144
        data.reuseAddress=false
        data.bind(InetSocketAddress(dataPort))
        data.soTimeout=250
        bindSocket(data)
        val hello=DatagramSocket(0)
        helloSocket=hello;hello.soTimeout=250;bindSocket(hello)
        return Pair(data,hello)
    }
    private fun receiveLoop() {
        val protocol=AircatWifiProtocol()
        val parser=AircatBscStream()
        val timing=LiveNorthTiming()
        val startMono=monotonicMs()
        val startEpoch=System.currentTimeMillis()/1000.0
        var lastHello=startMono-2000
        var lastData: Long?=null
        var lastNetworkError=""
        var lastAck: Long?=null
        var helloSent=0L
        var ackReceived=0L
        fun debug()="UDP HELLO $host:$helloPort · DATA :$dataPort · HELLO sent=$helloSent · ACK received=$ackReceived · $lastNetworkError"
        try {
            val address=InetAddress.getByName(host)
            val (data,hello)=openSockets() ?: return
            val bytes=ByteArray(2048)
            while(!stopped) {
                var now=monotonicMs()
                if(now-lastHello>=2000) {
                    lastHello=now
                    try {
                        val request="AIRCAT_HELLO_V1 $pin".toByteArray(Charsets.US_ASCII)
                        helloSent++
                        hello.send(DatagramPacket(request,request.size,address,helloPort))
                        val ack=DatagramPacket(ByteArray(256),256)
                        hello.receive(ack)
                        if(ack.address==address && ack.port==helloPort &&
                            protocol.acceptHello(ack.data.copyOf(ack.length))){
                            lastAck=monotonicMs();ackReceived++;lastNetworkError=""
                        } else lastNetworkError="Μη αναμενόμενη απάντηση HELLO (πηγή/μορφή)"
                    } catch(ex: WifiBusyException){throw ex}
                    catch(_: SocketTimeoutException){lastNetworkError="ACK timeout"}
                    catch(ex: java.io.IOException){if(stopped)break;lastNetworkError=ex.message ?: "Σφάλμα διαδρομής Wi-Fi"}
                }
                now=monotonicMs()
                val confirmed=lastAck
                if(confirmed==null && now-startMono>=handshakeTimeoutMs)
                    error("Wi-Fi/DHCP διαθέσιμα, αλλά δεν επιβεβαιώθηκε το PIN/HELLO. Πιθανές αιτίες: PIN, UDP διαδρομή ή ESP32.")
                if(confirmed!=null && now-confirmed>=ackTimeoutMs)
                    error("Χάθηκε η επιβεβαίωση HELLO/ACK για ${(now-confirmed)/1000}s.")
                try {
                    val datagram=DatagramPacket(bytes,bytes.size)
                    data.receive(datagram)
                    now=monotonicMs()
                    if(datagram.address!=address)protocol.rejectSource()
                    else protocol.decode(bytes,datagram.length,now)?.let { chunk ->
                        if(chunk.resetStream)parser.transportGap()
                        val epoch=startEpoch+(now-startMono)/1000.0
                        val packets=parser.feed(chunk.bytes,epoch)
                        for(packet in packets) {
                            if (packet.kind==0x19) timing.add(packet.epochSeconds)
                            recorder?.offer(WifiRecordRow(packet,protocol.snapshot()))
                            frames.add(packet)
                        }
                        lastData=now
                    }
                } catch(_: SocketTimeoutException){}
                catch(ex: java.net.SocketException){if(stopped)break;throw ex}
                val s=protocol.snapshot()
                val age=lastData?.let{(monotonicMs()-it).coerceAtLeast(0)}
                val message=when {
                    lastAck==null -> "Αναμονή HELLO/ACK από τη συσκευή..."
                    age==null -> "ACK OK · αναμονή DATA/CLOCK"
                    age>3000 -> "Wi-Fi ACK · αναμονή νέων δεδομένων (${age/1000}s)"
                    else -> "Ζωντανή λήψη SYNC2WIFI"
                }
                snapshot=WifiSessionSnapshot(s,parser.snapshot(),message,true,age,timing.snapshot(),
                    lastAck?.let { (monotonicMs()-it).coerceAtLeast(0) },helloSent,ackReceived)
            }
        } catch(ex: Exception) {
            if(!stopped)snapshot=WifiSessionSnapshot(protocol.snapshot(),parser.snapshot(),"Σφάλμα Wi-Fi: ${ex.message}\n"+debug(),false,timing=timing.snapshot(),
                lastAckAgoMs=lastAck?.let { (monotonicMs()-it).coerceAtLeast(0) },helloSent=helloSent,ackReceived=ackReceived)
        } finally {
            close()
            if(snapshot.running)snapshot=snapshot.copy(message="Η λήψη σταμάτησε",running=false)
        }
    }
    @Synchronized override fun close() {
        stopped=true;dataSocket?.close();helloSocket?.close();dataSocket=null;helloSocket=null;recorder?.stop()
    }
}

