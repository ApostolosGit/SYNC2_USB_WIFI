plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "gr.aircat.android"
    compileSdk = 35

    defaultConfig {
        applicationId = "gr.aircat.androidradaranalyzer.tcplab"
        minSdk = 26
        targetSdk = 35
        versionCode = 16
        versionName = "6.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}


dependencies { testImplementation("junit:junit:4.13.2") }
